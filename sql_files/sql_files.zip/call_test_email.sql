#email_sender = BigdataSesClient();
#email_sender.add_to('dvasquez@bancoripley.com,eapinoh@bancoripley.com,egalveze@bancoripley.com,mvargasc@bancoripley.com,hlunaa@bancoripley.com,cecheverriarr@bancoripley.com,jvaldebenitot@bancoripley.com,rbuguenoe@bancoripley.com,rarcosm@bancoripley.com,jaburtom@ripley.com,nverdejog@bancoripley.com');
#email_sender.add_subject('AWS MAIL AUTOMATICO: TEST_MAILS_AUTOMATICOS_AWS');
#email_sender.add_text('Estimados,\n \n Esta es una prueba de validación de correos \n Favor confirmar si le ha llegado este email \n \n \n Gracias! \n Saludos Cordiales \n Equipo Arquitectura de Datos y Automatización \n Gerencia Data Analytics');
#email_sender.send_email();