call schm_artifacts.sp_run_dgtl_logueos_internet();
call schm_digital.sp_dgtl_reporte_captacion();