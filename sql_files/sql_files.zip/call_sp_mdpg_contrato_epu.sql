call schm_artifacts.sp_mdpg_contrato_epu(schm_artifacts.f_first_day(current_date), last_day(current_date), schm_artifacts.f_period(current_date));
