call schm_artifacts.sp_ppff_retira_plastico(trunc(current_date));
