call schm_artifacts.sp_spos_transacciones_pasivos(schm_artifacts.f_first_day(current_date), last_day(current_date), schm_artifacts.f_period(current_date));
