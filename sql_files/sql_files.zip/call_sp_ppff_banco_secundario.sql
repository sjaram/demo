call schm_artifacts.sp_ppff_banco_secundario();
