call schm_digital.sp_dgtl_oferta_perfil_login_curses(datepart(year,current_date),datepart(month,current_date),cast(date_part(year, current_date)*100+date_part(month, current_date) as int));

