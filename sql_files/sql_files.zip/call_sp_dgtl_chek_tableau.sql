call schm_artifacts.sp_dgtl_chek_tableau();
