CALL schm_artifacts.cupon_capta('pdyQnXn1QRoYNT0OrMZN','CAMPAIGN_INPUT_FIREBASE_CUPON_CAPTA'
,'SJARAM'
,TO_CHAR(GETDATE(), 'YYYYMMDD')
,'select * from schm_data_analytics.cupon_capta');