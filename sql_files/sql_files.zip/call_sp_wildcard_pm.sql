call schm_campanas.sp_reporte_aperturas_email();
call schm_campanas.sp_reporte_aperturas_por_negocios();