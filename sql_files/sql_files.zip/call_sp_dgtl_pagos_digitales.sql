call schm_artifacts.sp_run_mdpg_pagos_digitales();

call schm_artifacts.sp_run_ppff_operaciones_dap();
