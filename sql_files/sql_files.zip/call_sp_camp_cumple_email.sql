call schm_artifacts.sp_camp_cumple_email('CAMPAIGN_INPUT_TR_CAMPANA',schm_artifacts.f_period(current_date), 'SJARAM', 'select * from schm_data_analytics.base_birthday_campaign');
