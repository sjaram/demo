call schm_artifacts.sp_run_SPOS_FOTO_RUBRO()
