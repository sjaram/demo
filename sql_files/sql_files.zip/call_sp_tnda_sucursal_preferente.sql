call schm_artifacts.sp_tnda_sucursal_preferente();
call schm_artifacts.sp_tnda_data_mkp(schm_artifacts.f_period(current_date));