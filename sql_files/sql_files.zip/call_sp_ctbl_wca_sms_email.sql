call schm_artifacts.sp_ctbl_wca_sms_email('CAMPAIGN_INPUT_EMAIL_WCA_REV','CAMPAIGN_INPUT_FONOS_SMS_REV','SJARAM'
,TO_CHAR(GETDATE(), 'YYYYMMDD'),'select * from schm_workspace.email_inhibir_wca'
,'select * from schm_workspace.fonos_inhibir_sms');