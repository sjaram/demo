CALL schm_artifacts.sp_ctbl_notcall_seguros('NOTCALL',TO_CHAR(GETDATE(), 'YYYYMMDD'),'select * from schm_data_analytics.notcall');
