call schm_artifacts.sp_run_spos_aut();
call schm_artifacts.sp_run_mdpg_trx_mcchek();