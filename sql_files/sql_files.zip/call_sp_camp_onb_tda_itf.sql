CALL schm_artifacts.sp_camp_onb_tda_itf('CAMPAIGN_INPUT_TR_TRANSAC_TDA','SJARAM',TO_CHAR(GETDATE(), 'YYYYMM'),'select * from schm_data_analytics.tr_transac_tda');
