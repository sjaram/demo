call schm_artifacts.sp_ctbl_inhib_sernac();
#move_sernac_files()