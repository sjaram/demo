CALL schm_artifacts.sp_ctbl_contact_seguros('BASE_TRABAJO_EMAIL',TO_CHAR(GETDATE(), 'YYYYMMDD'),'select * from schm_data_analytics.base_trabajo_email');
CALL schm_artifacts.sp_ctbl_contact_seguros('FONOS_MOVIL_FINAL',TO_CHAR(GETDATE(), 'YYYYMMDD'),'select * from schm_data_analytics.fonos_movil_final');
#sftp_redshift_sender('fiden_ftp',f'ctbl/contact_seguros/BASE_TRABAJO_EMAIL.csv',f'base_contacto_cliente/BASE_TRABAJO_EMAIL.csv',600);
#sftp_redshift_sender('fiden_ftp',f'ctbl/contact_seguros/FONOS_MOVIL_FINAL.csv',f'base_contacto_cliente/FONOS_MOVIL_FINAL.csv',600);