call schm_digital.sp_dgtl_reporte_rpass_trx_idnow();
